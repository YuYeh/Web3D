var shelljs = require('shelljs');
var express = require('express');
var app = express();

app.get('/', function(req, res){
  res.sendFile(__dirname + '/Homework_4.html');
});

app.get ('/api', function (req, res) {

	var max_x = req.query.max_x;
	var max_y = req.query.max_y;
	var min_x = req.query.min_x;
	var min_y = req.query.min_y;
	var center_x = req.query.center_x;
	var center_y = req.query.center_y;
	var radius = req.query.radius;
	
	shelljs.exec('CircleRect.exe ' + max_x + ' ' + max_y + ' ' + min_x + ' ' + min_y + ' ' + center_x + ' ' + center_y + ' ' + radius, function(status, output) {
	  //console.log('Exit status:', status);
	  //console.log('Program output:', output);
		console.log(output);
      var output = {
        status: status,
        output: output
      };

		
      /*
        The response header for supporting CORS:
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type"
      */

	  res.writeHead(200, {
		  "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type"
	  });
	
	  res.write( JSON.stringify(output) );
	  res.end();

	});

});


// or simply
// app.listen (1337); 
// will do

var server = app.listen (1337, function() {
	var host = server.address().address;
	var port = server.address().port;
	console.log ('server started on http://' + host + ':' + port);
});

